#!/usr/bin/env bash
set -euo pipefail

# Minimal command-line build for ITthute Multimedia Toolkit (alpha27 compatibility line).
# Required: Android SDK platform 28 and an Android build-tools installation
# containing aapt, zipalign, apksigner and either d8 or dx.
ROOT=$(cd "$(dirname "$0")" && pwd)
ANDROID_HOME=${ANDROID_HOME:?Set ANDROID_HOME to your Android SDK directory}
BUILD_TOOLS_VERSION=${BUILD_TOOLS_VERSION:-28.0.3}
BT="$ANDROID_HOME/build-tools/$BUILD_TOOLS_VERSION"
PLATFORM="$ANDROID_HOME/platforms/android-28/android.jar"
BUILD="$ROOT/build"

for required in "$BT/aapt" "$BT/zipalign" "$PLATFORM"; do
  if [[ ! -e "$required" ]]; then
    echo "Missing required Android SDK component: $required" >&2
    exit 2
  fi
done

rm -rf "$BUILD/apk" "$BUILD/gen" "$BUILD/classes" "$BUILD/dex"
mkdir -p "$BUILD/apk" "$BUILD/gen" "$BUILD/classes" "$BUILD/dex"

"$BT/aapt" package -f -m -J "$BUILD/gen" \
  -M "$ROOT/AndroidManifest.xml" -S "$ROOT/res" -I "$PLATFORM"

find "$ROOT/src" "$BUILD/gen" -name '*.java' -print > "$BUILD/sources.txt"
javac -source 8 -target 8 -bootclasspath "$PLATFORM" \
  -d "$BUILD/classes" @"$BUILD/sources.txt"

# Build-tools 28.0.3 d8 has known compatibility problems with class files
# produced by some modern JDKs. Prefer dx for this Java 8 application when it
# is present, while retaining d8 as a fallback for newer SDK installations.
DEXER=${DEXER:-auto}
if [[ "$DEXER" == "dx" || ( "$DEXER" == "auto" && -x "$BT/dx" ) ]]; then
  [[ -x "$BT/dx" ]] || { echo "Requested dx was not found under $BT" >&2; exit 3; }
  "$BT/dx" --dex --output="$BUILD/classes.dex" "$BUILD/classes"
elif [[ "$DEXER" == "d8" || ( "$DEXER" == "auto" && -x "$BT/d8" ) ]]; then
  [[ -x "$BT/d8" ]] || { echo "Requested d8 was not found under $BT" >&2; exit 3; }
  (cd "$BUILD/classes" && jar cf "$BUILD/classes.jar" .)
  "$BT/d8" --lib "$PLATFORM" --output "$BUILD/dex" "$BUILD/classes.jar"
  cp "$BUILD/dex/classes.dex" "$BUILD/classes.dex"
else
  echo "Neither dx nor d8 was found under $BT" >&2
  exit 3
fi

"$BT/aapt" package -f -M "$ROOT/AndroidManifest.xml" \
  -S "$ROOT/res" -I "$PLATFORM" -F "$BUILD/apk/unsigned-unaligned.apk"
(
  cd "$BUILD"
  "$BT/aapt" add apk/unsigned-unaligned.apk classes.dex
)
"$BT/zipalign" -f 4 "$BUILD/apk/unsigned-unaligned.apk" "$BUILD/apk/ITthute-Multimedia-Toolkit-v2.0.0-alpha27-unsigned.apk"

printf '\nUnsigned aligned APK:\n  %s\n\n' "$BUILD/apk/ITthute-Multimedia-Toolkit-v2.0.0-alpha27-unsigned.apk"
echo "Run ./sign-release.sh with the retained ITthute release key."
